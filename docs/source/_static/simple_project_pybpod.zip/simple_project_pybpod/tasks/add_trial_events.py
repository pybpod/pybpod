# !/usr/bin/python3
# -*- coding: utf-8 -*-

"""
Demonstration of AddTrialEvents used in a simple visual 2AFC session.
AddTrialEvents formats each trial's data in a human-readable struct, and adds to myBpod.data (to save to disk later)
Connect noseports to ports 1-3.

Example adapted from Josh Sanders' original version on Sanworks Bpod repository
"""

import random
from pybpodapi.model.state_machine import StateMachine


my_bpod = BPOD_INSTANCE

nTrials = 4
trialTypes = [1, 2]  # 1 (rewarded left) or 2 (rewarded right)

for i in range(nTrials):  # Main loop
	print('Trial: {0}'.format(i + 1))

	thisTrialType = random.choice(trialTypes)  # Randomly choose trial type
	if thisTrialType == 1:
		stimulus = 'PWM1'  # set stimulus channel for trial type 1
		leftAction = 'Reward'
		rightAction = 'Punish'
		rewardValve = 1
	elif thisTrialType == 2:
		stimulus = 'PWM3'  # set stimulus channel for trial type 1
		leftAction = 'Punish'
		rightAction = 'Reward'
		rewardValve = 3

	sma = StateMachine(my_bpod.hardware)

	sma.add_state(
		state_name='WaitForPort2Poke',
		state_timer=1,
		state_change_conditions={'Port2In': 'FlashStimulus'},
		output_actions=[('PWM2', 255)])
	sma.add_state(
		state_name='FlashStimulus',
		state_timer=0.1,
		state_change_conditions={'Tup': 'WaitForResponse'},
		output_actions=[(stimulus, 255)])
	sma.add_state(
		state_name='WaitForResponse',
		state_timer=1,
		state_change_conditions={'Port1In': leftAction, 'Port3In': rightAction},
		output_actions=[])
	sma.add_state(
		state_name='Reward',
		state_timer=0.1,
		state_change_conditions={'Tup': 'exit'},
		output_actions=[('Valve', rewardValve)])  # Reward correct choice
	sma.add_state(
		state_name='Punish',
		state_timer=3,
		state_change_conditions={'Tup': 'exit'},
		output_actions=[('LED', 1), ('LED', 2), ('LED', 3)])  # Signal incorrect choice

	my_bpod.send_state_machine(sma)  # Send state machine description to Bpod device

	print("Waiting for poke. Reward: {0}".format('left' if thisTrialType == 1 else 'right'))

	my_bpod.run_state_machine(sma)  # Run state machine

	print("Raw events: {0}".format(sma.raw_data))


